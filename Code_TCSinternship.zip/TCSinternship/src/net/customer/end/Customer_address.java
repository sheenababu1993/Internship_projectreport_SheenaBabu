package net.customer.end;

//import java.io.FileInputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Customer_address
{

	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver driver = new FirefoxDriver();
	    //Thread.sleep(3000);
	    driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		//1)Login using the credentials. Check for valid and invalid test cases		
	   //valid email and password
		//click Account button
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/a/strong")).click();
	  //click login button
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/div[2]/ul/li[3]/ul/li[1]/a")).click();
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("user@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demouser");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
		System.out.println("login successfully");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/div[1]/div/div[1]/div[2]/ul/li[3]/a\r\n")).click();
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("demouser");
	    driver.findElement(By.xpath("/html/body/div[1]/div/section[1]/div/div/div/div/div/div[2]/form/div/div[6]/button")).click();
	    Thread.sleep(2000);
        driver.quit();


	}

}
