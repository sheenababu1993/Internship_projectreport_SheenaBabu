package net.agent.end;
//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Agent_destination {

	public static void main(String[] args) throws InterruptedException {
		 WebDriver driver = new FirefoxDriver();
		driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//3)Create a script that would test the links Home, Hotels, Tours, Visa, Blog, Offers and direct to the destination page.
	//valid email and password
	//Home
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("agent@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoagent");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
		
	//Hotels
		Thread.sleep(2000);
		WebElement hotel=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(2) > a"));
		hotel.click();
	//Tours
		Thread.sleep(2000);
		WebElement tours=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(3) > a"));
		tours.click();
	//Flights
		Thread.sleep(2000);
		WebElement flights=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(1) > a"));
		flights.click();
	//Blog
		Thread.sleep(2000);
		WebElement blog=driver.findElement(By.cssSelector("#navbarSupportedContent > div.nav-item--left.ms-lg-5 > ul > li:nth-child(5) > a"));
		blog.click();
		driver.quit();
		
	}

}

