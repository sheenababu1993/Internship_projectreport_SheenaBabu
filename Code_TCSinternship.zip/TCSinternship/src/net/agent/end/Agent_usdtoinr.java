package net.agent.end;

//import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Agent_usdtoinr {

	public static void main(String[] args) throws InterruptedException 
	{
		
		WebDriver driver = new FirefoxDriver();
        driver.get("https://www.phptravels.net/login");
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//Develop the script that would update USD to INR for the account.
	//valid email and password
		Thread.sleep(2000);
		WebElement email=driver.findElement(By.id("email"));
		email.sendKeys("agent@phptravels.com");
		WebElement pwd=driver.findElement(By.id("password"));
		pwd.sendKeys("demoagent");
		Thread.sleep(2000);
		WebElement login=driver.findElement(By.id("submitBTN"));
		login.click();
	//Click USD
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/header/div/div[2]/div[2]/ul/li[2]/a")).click();
		
	//select INR
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/header/div/div[2]/div[2]/ul/li[2]/ul/li[4]/a")).click();
		
		Thread.sleep(2000);
		//driver.quit();
		

	}

}
