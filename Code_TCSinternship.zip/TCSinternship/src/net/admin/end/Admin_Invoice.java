package net.admin.end;
import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.support.ui.Select;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
public class Admin_Invoice 
{

	public static void main(String[] args) throws InterruptedException 
	{
		//System.setProperty("webdriver.chrome.driver","E:\\JAVA\\Selenium_TEST\\Drivers\\chromedriver.exe");

		 WebDriver driver = new FirefoxDriver();
	    Thread.sleep(3000);
	    driver.get("https://phptravels.net/admin/login.php");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='email']")).sendKeys("admin@phptravels.com");
		driver.findElement(By.xpath("//input[@id='password']")).sendKeys("demoadmin");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/main/header/ul/li[10]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"search_type\"]")).click();
		driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div[1]/form/div[3]/div/select/option[3]")).click();
        
		
		
		driver.findElement(By.xpath("//*[@id=\"search_type\"]")).click();
		driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div[1]/form/div[4]/div/select/option[2]")).click();
       	driver.findElement(By.xpath("/html/body/main/section/div[2]/div/div[1]/form/div[6]/button")).click();
		
       	driver.findElement(By.xpath("//html/body/main/section/div[2]/div/div[2]/figure/blockquote[2]/div/span/a")).click();
		
		//driver.findElement(By.xpath("//table[@class='table table-striped table-bordered dataTable no-footer']//tbody//tr//td//a")).click();
		
		
		Set<String> WindowHandles = driver.getWindowHandles();
		
		for(String winhnd:WindowHandles)
		{
			String hndl = driver.switchTo().window(winhnd).getTitle();
			if(hndl.equals("Hotels Invoice"))
			{
				System.out.println("Booking invoice displayed");
			}
		}
		
		Thread.sleep(3000);
	}
}
					
